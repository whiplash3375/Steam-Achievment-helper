# Steam-Achievements-Unlocker
  It helps you to unlocked all Achievements of your games.

# Procedure:
  1.Pick a game first.
  
  2.Capture 2 will explain what you want. 
  
![capture 1](https://user-images.githubusercontent.com/17538473/41518069-93b10e76-72f2-11e8-8f99-2c9cf36c4ab0.PNG)

![capture 2](https://user-images.githubusercontent.com/17538473/41518072-9677783e-72f2-11e8-8138-1cd973deb8d5.png)
